<?php

/**
 * Interface for IsbnService
 * @author MBlock, FSteffen
 * 
 */
interface IsbnService {
	
	public function getData($isbn = null);
	
}
