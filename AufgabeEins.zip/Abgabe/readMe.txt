aufgabeEins


isbnJson.php = REST-Schnittstelle;
dump = SQL-DB-Definition; (Hinweis==> Enspricht der Musterl�sung aus Aufgabe_3 + zus�tzlichem Inde auf der Spalte isbn zur effizienten Suche nach isbn
index.php = HTML-Part der Applikation ==> client-seitig;
DBCacheService = Cache-Layer;
